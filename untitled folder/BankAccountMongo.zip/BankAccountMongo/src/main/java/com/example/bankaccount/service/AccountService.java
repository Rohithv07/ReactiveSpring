package com.example.bankaccount.service;

import com.example.bankaccount.model.Account;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface AccountService {
	public Flux<Account> getAllAccountDetails();

	public Mono<Account> getAccountById(String id);

	public Mono<Account> createAccount(Account account);

	public Mono<Boolean> updateAccount(Account account);

	public Mono<Boolean> deleteAccount(String id);
}

/**
 * Account Service GET /accounts GET /accounts/{id} POST /accounts PUT
 * /accounts/{id} DELETE /accounts/{id}
 * 
 * public Flux<Employee> getAllEmployees(); public Mono<Employee>
 * getEmployee(Integer empId); public Mono<Employee> createEmployee(Employee
 * employee); public void updateEmployee(Employee employee); public void
 * deleteEmployee(Integer empId);
 */