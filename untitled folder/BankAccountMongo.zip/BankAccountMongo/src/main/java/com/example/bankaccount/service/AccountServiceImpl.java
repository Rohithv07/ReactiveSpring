package com.example.bankaccount.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bankaccount.model.Account;
import com.example.bankaccount.repository.BankAccountRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private BankAccountRepository bankAccountRepository;

	@Override
	public Flux<Account> getAllAccountDetails() {
		return bankAccountRepository.findAll();
	}

	@Override
	public Mono<Account> getAccountById(String id) {
		return bankAccountRepository.findById(id);
	}

	@Override
	public Mono<Account> createAccount(Account account) {
		return bankAccountRepository.save(account);
	}

	@Override
	public Mono<Boolean> updateAccount(Account account) {
		try {

			bankAccountRepository.save(account).block();
		} catch (Exception e) {
			return Mono.just(Boolean.FALSE);
		}
		return Mono.just(Boolean.TRUE);
	}

	@Override
	public Mono<Boolean> deleteAccount(String id) {
		try {
			bankAccountRepository.deleteById(id).block();
		} catch (Exception e) {
			return Mono.just(Boolean.FALSE);
		}
		return Mono.just(Boolean.TRUE);
	}

}
