package com.example.bankaccount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.bankaccount.webclient.BankWebClient;

@SpringBootApplication
public class BankAccountMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankAccountMongoApplication.class, args);
		BankWebClient bwc = new BankWebClient();
		System.out.println(bwc.getResultAccount());
	}

}
