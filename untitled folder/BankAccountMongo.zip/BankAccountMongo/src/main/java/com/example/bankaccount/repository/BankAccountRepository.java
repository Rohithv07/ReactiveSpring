package com.example.bankaccount.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.example.bankaccount.model.Account;

public interface BankAccountRepository extends ReactiveCrudRepository<Account, String>{

}
