package com.example.bankaccount.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bankaccount.model.Account;
import com.example.bankaccount.service.AccountService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	private AccountService accountService;

	@GetMapping
	public Flux<Account> getAllAccountDetails() {
		return accountService.getAllAccountDetails();
	}

	@GetMapping("/{id}")
	public Mono<Account> getAccountDetailsById(@PathVariable String id) {
		return accountService.getAccountById(id);
	}

	@PostMapping
	public Mono<Account> createNewAccount(@RequestBody Account account) {
		return accountService.createAccount(account);
	}

	@PutMapping("/{id}")
	public Mono<Void> updateAccountDetails(@RequestBody Account account, @PathVariable String id) {
		accountService.updateAccount(account);
		return null;
	}

	@DeleteMapping("/{id}")
	public Mono<Void> deleteAccount(@PathVariable String id) {
		accountService.deleteAccount(id);
		return null;
	}
}
