package com.example.bankaccount.webclient;

import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.bankaccount.model.Account;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class BankWebClient {
	private WebClient webClient = WebClient.create("http://localhost:8100");

	private Mono<ClientResponse> result1 = webClient.get().uri("/account").accept(MediaType.APPLICATION_JSON)
			.exchange();

	// private Mono<ClientResponse> result2 =
	// webClient.get().uri("/transfer").accept(MediaType.APPLICATION_JSON).exchange();

	public List<Account> getResultAccount() {
		Flux<Account> list = result1.flatMapMany(res -> res.bodyToFlux(Account.class));
		return list.collectList().block(); // block until the next signal is received

	}

	public Account getAccountById(Integer id) {
		return webClient.get().uri("/account/{id}", id).retrieve().bodyToMono(Account.class).block();
	}

}
