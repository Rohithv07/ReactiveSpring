package com.example.bankaccount.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.example.bankaccount.model.Account;
import com.example.bankaccount.service.AccountService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AccountControllerTest {

	@Autowired
	private WebTestClient webTestClient;

	@MockBean
	private AccountService accountService;

	@BeforeEach
	public void testAccount() {
		System.out.println("Started the testing");
	}

	@Test
	public void testGetAllAccountDetails() {
		List<Account> accountDetails = new ArrayList<>();
		Account account1 = new Account("1", "Name1", "Type1", LocalDate.now());
		Account account2 = new Account("2", "Name2", "Type2", LocalDate.now());
		Account account3 = new Account("3", "Name3", "Type3", LocalDate.now());
		accountDetails.add(account1);
		accountDetails.add(account2);
		accountDetails.add(account3);
		Mockito.when(accountService.getAllAccountDetails()).thenReturn(Flux.fromIterable(accountDetails));

		webTestClient.get().uri("/account").exchange().expectStatus().isOk().expectBodyList(Account.class).hasSize(3);
	}

	@Test
	public void testGetAllAccountDetails_Empty() {
		List<Account> accountDetails = new ArrayList<>();
		Mockito.when(accountService.getAllAccountDetails()).thenReturn(Flux.fromIterable(accountDetails));

		webTestClient.get().uri("/account").exchange().expectStatus().isOk().expectBodyList(Account.class).hasSize(0);
	}

	@Test
	public void testGetAccountDetails_Id() {
		Account account1 = new Account("1", "Name1", "Type1", LocalDate.now());
		Mockito.when(accountService.getAccountById("1")).thenReturn(Mono.just(account1));

		webTestClient.get().uri("/account/1").exchange()

				.expectStatus().isOk().expectBody()
//		.isEqualTo(employee);
				.jsonPath("$.id").isEqualTo(1);
	}

	@Test
	public void testGetAccountDetails_UnknownId() {
		Account account1 = new Account("1", "Name1", "Type1", LocalDate.now());
		Mockito.when(accountService.getAccountById("1")).thenReturn(Mono.just(account1));

		webTestClient.get().uri("/account/2").exchange()

				.expectStatus().isOk().expectBody().jsonPath("$.id").doesNotExist();
	}

	@Test
	public void testDeleteAccountDetails_Id() {
		Account account1 = new Account("1", "Name1", "Type1", LocalDate.now());
		Mockito.when(accountService.createAccount(account1)).thenReturn(Mono.just(account1));
		webTestClient.delete().uri("/account/1").exchange().expectStatus().isOk();
	}

	@Test
	public void testDeleteAccountDetails_UnknownId() {
		Account account1 = new Account("1", "Name1", "Type1", LocalDate.now());
		Mockito.when(accountService.createAccount(account1)).thenReturn(Mono.just(account1));
		webTestClient.delete().uri("/account/20").exchange().expectStatus().isOk();
	}

	@Test
	public void testCreateAccount() {
		Account account1 = new Account("1", "Name1", "Type1", LocalDate.now());
		Mockito.when(accountService.createAccount(account1)).thenReturn(Mono.just(account1));
		webTestClient.post().uri("/account").body(Mono.just(account1), Account.class).exchange().expectStatus()
				.isOk();
	}

}

/*
 * @Test public void testCreateEmployee() { Employee employee = new Employee(1,
 * "Anand", 30, "Male", false, "Lead", "IT", "Mumbai", "India");
 * Mockito.when(employeeService.createEmployee(employee)).thenReturn(Mono.just(
 * employee)); webTestClient.post().uri("/employees") .body(Mono.just(employee),
 * Employee.class)
 * .exchange().expectStatus().isCreated().expectBody().jsonPath("$.message").
 * isEqualTo("Employee created"); }
 */
