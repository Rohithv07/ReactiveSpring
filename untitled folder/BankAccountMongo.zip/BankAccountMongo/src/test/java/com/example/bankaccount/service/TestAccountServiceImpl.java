package com.example.bankaccount.service;

import static org.mockito.Mockito.when;

import java.time.LocalDate;

import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.example.bankaccount.model.Account;
import com.example.bankaccount.repository.BankAccountRepository;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

public class TestAccountServiceImpl {
	
//	@InjectMocks
//	private AccountService accountService;
	AccountServiceImpl accountService;
	
//	@Mock
//	private BankAccountRepository accountRepository;
	

	@BeforeAll
	public static void before() {
		System.out.println("Before All called...");
	}

	@BeforeEach
	public void setup() {
		System.out.println("New testing");
		accountService = new AccountServiceImpl();
	}

	@Test
	public void testGetAllEmployee() {
		Account account = new Account("1", "Raj", "Loan", LocalDate.now());
		accountService.createAccount(account);
		StepVerifier.create(accountService.getAllAccountDetails()).expectNextCount(5).expectComplete().verify();
	}

}
