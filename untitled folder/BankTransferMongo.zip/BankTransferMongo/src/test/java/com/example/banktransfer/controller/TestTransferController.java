package com.example.banktransfer.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.example.banktransfer.model.Account;
import com.example.banktransfer.model.Transfer;
import com.example.banktransfer.service.TransferService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TestTransferController {

	@Autowired
	private WebTestClient webTestClient;

	@MockBean
	private TransferService transferService;

	@BeforeEach
	public void testAccount() {
		System.out.println("Started the testing");
	}

	@Test
	public void testGetAllTransferDetails() {
		List<Transfer> transferDetails = new ArrayList<>();
		Transfer transfer1 = new Transfer("1", "Type1", 100, "description",
				new Account("1", "raj", "Type1", LocalDate.now()));
		Transfer transfer2 = new Transfer("2", "Type2", 100, "description",
				new Account("2", "rag", "Type2", LocalDate.now()));
		Transfer transfer3 = new Transfer("3", "Type3", 100, "description",
				new Account("3", "rav", "Type3", LocalDate.now()));
		transferDetails.add(transfer1);
		transferDetails.add(transfer2);
		transferDetails.add(transfer3);

		Mockito.when(transferService.getAllTransfer()).thenReturn(Flux.fromIterable(transferDetails));

		webTestClient.get().uri("/transfer").exchange().expectStatus().isOk().expectBodyList(Transfer.class).hasSize(3);
	}

	@Test
	public void testGetAllTransferDetails_Empty() {
		List<Transfer> transferDetails = new ArrayList<>();
		Mockito.when(transferService.getAllTransfer()).thenReturn(Flux.fromIterable(transferDetails));

		webTestClient.get().uri("/transfer").exchange().expectStatus().isOk().expectBodyList(Transfer.class).hasSize(0);
	}

	@Test
	public void testTransferDetails_Id() {
		Transfer transfer = new Transfer("1", "Type1", 100, "description",
				new Account("1", "raj", "Type1", LocalDate.now()));
		Mockito.when(transferService.getTransferById("1")).thenReturn(Mono.just(transfer));

		webTestClient.get().uri("/transfer/1").exchange()

				.expectStatus().isOk().expectBody().jsonPath("$.id").isEqualTo(1);
	}

	@Test
	public void testTransferDetails_UnknownId() {
		Transfer transfer = new Transfer("1", "Type1", 100, "description",
				new Account("1", "raj", "Type1", LocalDate.now()));
		Mockito.when(transferService.getTransferById("1")).thenReturn(Mono.just(transfer));

		webTestClient.get().uri("/transfer/2").exchange()

				.expectStatus().isOk().expectBody().jsonPath("$.id").doesNotExist();
	}

	@Test
	public void testCreateTransfer() {
		Transfer transfer = new Transfer("1", "Type1", 100, "description",
				new Account("1", "raj", "Type1", LocalDate.now()));
		Mockito.when(transferService.createTransfer(transfer)).thenReturn(Mono.just(transfer));
		webTestClient.post().uri("/transfer").body(Mono.just(transfer), Transfer.class).exchange().expectStatus()
				.isOk();
	}

}
