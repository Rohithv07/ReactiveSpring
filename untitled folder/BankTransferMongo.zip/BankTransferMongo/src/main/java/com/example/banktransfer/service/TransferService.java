package com.example.banktransfer.service;

import com.example.banktransfer.model.Account;
import com.example.banktransfer.model.Transfer;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface TransferService {

	public Flux<Transfer> getAllTransfer();

	public Mono<Transfer> getTransferById(String id);

	public Mono<Transfer> createTransfer(Transfer transfer);

	public Mono<Boolean> updateTransfer(Transfer transfer);

	public Mono<Boolean> deleteTransfer(String id);
	
	public Mono<Account> findTransferOfAnAccountById(String id);
	
	//public Mono<Transfer> accountTransfer(Integer id);

	//public Mono<Transfer> accountTransferDetail(Integer idAccount, Integer idTransfer);

}

/**
 * GET /transactions GET /transactions/{id} POST /transactions PUT
 * /transactions/{id} DELETE /transactions/{id}
 * 
 * GET /accounts/{id}/transactions GET /accounts/{id}/transactions/{id}
 */