package com.example.banktransfer.repository;

import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.example.banktransfer.model.Account;
import com.example.banktransfer.model.Transfer;

import reactor.core.publisher.Mono;

public interface BankTransferRepository extends ReactiveCrudRepository<Transfer, String>{

	@Query("{'transfer.account':?0}")
	Mono<Account> findAccountByTransferId(String id);
}
