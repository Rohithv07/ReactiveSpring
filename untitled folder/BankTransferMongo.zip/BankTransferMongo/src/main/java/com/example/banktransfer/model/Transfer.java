package com.example.banktransfer.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Transfer {

	@Id
	private String id;
	private String type;
	private double amount;
	private String description;
	private Account account;

	public Transfer() {
	}

	public Transfer(String id, String type, double amount, String description, Account account) {
		this.id = id;
		this.type = type;
		this.amount = amount;
		this.description = description;
		this.account = account;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Transfer [id=" + id + ", type=" + type + ", amount=" + amount + ", description=" + description
				+ ", account=" + account + "]";
	}

}
