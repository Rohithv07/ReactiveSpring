package com.example.banktransfer.webclient;

import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.banktransfer.model.Account;
import com.example.banktransfer.model.Transfer;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class BankWebClient {
	private WebClient webClientAccount = WebClient.create("http://localhost:8100");
	private WebClient webClientTransfer = WebClient.create("http://localhost:8101");

	private Mono<ClientResponse> result2 = webClientTransfer.get().uri("/transfer").accept(MediaType.APPLICATION_JSON)
			.exchange();

	public List<Transfer> getResultTransfer() {
		Flux<Transfer> list = result2.flatMapMany(res -> res.bodyToFlux(Transfer.class));
		return list.collectList().block();
	}

	public Account getAccountById(Integer id) {
		return webClientAccount.get().uri("/account/{id}", id).retrieve().bodyToMono(Account.class).block();
	}

}
