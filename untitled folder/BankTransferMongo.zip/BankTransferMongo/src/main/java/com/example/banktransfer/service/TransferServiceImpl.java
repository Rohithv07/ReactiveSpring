package com.example.banktransfer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.banktransfer.model.Account;
import com.example.banktransfer.model.Transfer;
import com.example.banktransfer.repository.BankTransferRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class TransferServiceImpl implements TransferService {

	//private BankWebClient bwc = new BankWebClient();

	@Autowired
	private BankTransferRepository bankTransferRepository;

//	private Account getAccountByCalling(Integer id) {
//		return bwc.getAccountById(id);
//	}

	@Override
	public Flux<Transfer> getAllTransfer() {
		return bankTransferRepository.findAll();
	}

	@Override
	public Mono<Transfer> getTransferById(String id) {
		return bankTransferRepository.findById(id);
	}

	@Override
	public Mono<Transfer> createTransfer(Transfer transfer) {
		return bankTransferRepository.save(transfer);
	}

	@Override
	public Mono<Boolean> updateTransfer(Transfer transfer) {
		try {

			bankTransferRepository.save(transfer).block();
		} catch (Exception e) {
			return Mono.just(Boolean.FALSE);
		}
		return Mono.just(Boolean.TRUE);
	}

	@Override
	public Mono<Boolean> deleteTransfer(String id) {
		try {
			bankTransferRepository.deleteById(id).block();
		} catch (Exception e) {
			return Mono.just(Boolean.FALSE);
		}
		return Mono.just(Boolean.TRUE);
	}
	
	@Override
	public Mono<Account> findTransferOfAnAccountById(String id) {
		return bankTransferRepository.findAccountByTransferId(id);
	}

}
